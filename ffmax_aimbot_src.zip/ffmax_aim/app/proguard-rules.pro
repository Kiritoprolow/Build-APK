# Keep service class names (referenced by system via manifest)
-keep class com.overlay.assist.AimbotService { *; }
-keep class com.overlay.assist.MainActivity  { *; }

# Keep accessibility service config class
-keepclassmembers class com.overlay.assist.** { *; }

# Suppress warnings for unused AndroidX internals
-dontwarn androidx.**
