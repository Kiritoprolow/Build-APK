// language: Kotlin, file: MainActivity.kt, target: Android API 26+
// Entry point. Walks the user through the three permission steps needed:
//   1. SYSTEM_ALERT_WINDOW  — draw overlay circle
//   2. Accessibility Service — enable in Settings (can't be granted via code)
//   3. MediaProjection       — one-time "start capturing" dialog
//
// After all three: fires the START_CAPTURE Intent to AimbotService,
// then minimises itself (user goes back to FF MAX).
//
// Anti-detection: app label is "Phone Assistant", icon is generic phone icon.
// The app has no tiles in recent-apps history (excludeFromRecents=true would
// need manifest flag; set if desired).

package com.overlay.assist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private val OVERLAY_REQ = 100

    // MediaProjection result launcher
    private val projLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            sendCaptureIntent(result.resultCode, result.data!!)
            status.text = "✅ All set — open Free Fire MAX. Long-press Vol↓ to toggle."
            // Minimise after 1s
            window.decorView.postDelayed({ moveTaskToBack(true) }, 1200)
        } else {
            status.text = "❌ Screen capture permission denied."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Simple programmatic UI — no XML layout needed
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
        }
        setContentView(root)

        status = TextView(this).apply {
            text = "Checking permissions…"
            textSize = 14f
        }

        val btnOverlay = Button(this).apply {
            text = "1 — Grant Overlay Permission"
            setOnClickListener { requestOverlay() }
        }
        val btnA11y = Button(this).apply {
            text = "2 — Enable Accessibility Service"
            setOnClickListener { openA11ySettings() }
        }
        val btnCapture = Button(this).apply {
            text = "3 — Start Screen Capture"
            setOnClickListener { requestCapture() }
        }
        val btnStop = Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(this@MainActivity, AimbotService::class.java)) }
        }

        root.addView(status)
        root.addView(Space(this).apply { minimumHeight = 24 })
        root.addView(btnOverlay)
        root.addView(btnA11y)
        root.addView(btnCapture)
        root.addView(btnStop)

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ── Step 1: Overlay ──────────────────────────────────────────────────────
    private fun requestOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(i, OVERLAY_REQ)
        } else {
            status.text = "Overlay already granted."
        }
    }

    // ── Step 2: Accessibility ────────────────────────────────────────────────
    private fun openA11ySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        status.text = "Enable \"Visual Accessibility Aid\" in Accessibility → Installed services."
    }

    // ── Step 3: MediaProjection ───────────────────────────────────────────────
    private fun requestCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mgr.createScreenCaptureIntent())
    }

    // ── Send to service ───────────────────────────────────────────────────────
    private fun sendCaptureIntent(code: Int, data: Intent) {
        val i = Intent(this, AimbotService::class.java).apply {
            action = AimbotService.ACTION_START
            putExtra(AimbotService.EXTRA_RESULT_CODE, code)
            putExtra(AimbotService.EXTRA_RESULT_DATA, data)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(i)
        } else {
            startService(i)
        }
    }

    // ── Status ────────────────────────────────────────────────────────────────
    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val a11y   = isA11yEnabled()
        status.text = buildString {
            append("Overlay: ${if (overlay) "✅" else "❌"}\n")
            append("Accessibility: ${if (a11y) "✅" else "❌"}\n")
            append(if (overlay && a11y)
                "Ready — tap \"Start Screen Capture\" then open FF MAX."
            else
                "Complete the steps above first.")
        }
    }

    private fun isA11yEnabled(): Boolean {
        val flat = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return flat.contains("${packageName}/${AimbotService::class.java.name}")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_REQ) refreshStatus()
    }
}
