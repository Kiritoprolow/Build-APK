// language: Kotlin, file: AimbotService.kt, target: Android API 26+
// Core service: extends AccessibilityService so it can inject gestures without root.
// Also runs as a foreground service of type mediaProjection for screen capture.
//
// Lifecycle:
//   1. Service bound by Android Accessibility framework when user enables it in Settings.
//   2. MainActivity sends a START_CAPTURE Intent with MediaProjection resultCode + data.
//   3. Service starts ForegroundService (required before creating MediaProjection on API 34+).
//   4. ScreenCapture pipeline starts → frames arrive on background thread.
//   5. Each frame: EnemyDetector scans FOV area → AimEngine fires gesture if target found.
//   6. Toggle: volume-down long-press or overlay button to enable/disable.
//
// Key: FOV circle bounds in capture-space = (screenCenter / scaleX, radius / scaleX)

package com.overlay.assist

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat

class AimbotService : AccessibilityService() {

    companion object {
        const val ACTION_START = "com.overlay.assist.START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP  = "com.overlay.assist.STOP_CAPTURE"
        const val NOTIF_CHANNEL = "assist_channel"
        const val NOTIF_ID = 1
        private const val TAG = "AimbotService"

        @Volatile var instance: AimbotService? = null
    }

    private var capture: ScreenCapture? = null
    private var overlay: OverlayView? = null
    private var aimEngine: AimEngine? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var screenW = 1080
    private var screenH = 2400
    private var densityDpi = 420

    // FOV circle radius in screen pixels (synced from OverlayView's dp value)
    private var fovRadiusPx = 260f  // ≈ 130dp @ 2x density

    // Aimbot on/off toggle (user-controlled via volume key)
    @Volatile var aimbotEnabled = true

    // Volume-key long-press detector
    private var volDownAt = 0L

    // ── Service lifecycle ────────────────────────────────────────────────────
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "service connected")
        createNotifChannel()
        measureScreen()
        attachOverlay()
        aimEngine = AimEngine(this).apply { setScreenSize(screenW, screenH) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else
                    @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (code != -1 && data != null) {
                    startForegroundCapture(code, data)
                }
            }
            ACTION_STOP -> stopCapture()
        }
        return START_STICKY
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }
    override fun onInterrupt() { stopCapture() }

    override fun onUnbind(intent: Intent?): Boolean {
        stopCapture()
        detachOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ── Volume key toggle ────────────────────────────────────────────────────
    // Long-press volume-down (>400ms) toggles aimbot on/off
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        event ?: return false
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> volDownAt = System.currentTimeMillis()
                KeyEvent.ACTION_UP -> {
                    val held = System.currentTimeMillis() - volDownAt
                    if (held > 400) {
                        aimbotEnabled = !aimbotEnabled
                        overlay?.aimbotActive = false
                        mainHandler.post { overlay?.invalidate() }
                        return true  // consume the key event
                    }
                }
            }
        }
        return false
    }

    // ── Foreground + MediaProjection ─────────────────────────────────────────
    private fun startForegroundCapture(resultCode: Int, data: Intent) {
        // Must start foreground BEFORE creating MediaProjection (API 34+ requirement)
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection: MediaProjection = mgr.getMediaProjection(resultCode, data)

        // Register stop callback so we clean up if user revokes permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, mainHandler)
        }

        capture = ScreenCapture(projection, screenW, screenH, densityDpi, ::onFrame).also {
            it.start()
        }

        Log.d(TAG, "capture live")
    }

    private fun stopCapture() {
        capture?.stop()
        capture = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        overlay?.aimbotActive = false
    }

    // ── Frame processing loop ────────────────────────────────────────────────
    // Runs on ScreenCapture's background HandlerThread
    private fun onFrame(bmp: Bitmap) {
        if (!aimbotEnabled || capture == null) return

        val scale = capture!!.scaleX  // same as scaleY assuming uniform
        val capFovRadius = fovRadiusPx / scale

        // FOV rect in capture-bitmap space
        val capCx = (screenW / 2f) / scale
        val capCy = (screenH / 2f) / scale
        val fovRect = RectF(
            capCx - capFovRadius, capCy - capFovRadius,
            capCx + capFovRadius, capCy + capFovRadius
        )

        val targets = EnemyDetector.detect(bmp, fovRect)

        if (targets.isEmpty()) {
            if (overlay?.aimbotActive == true) {
                mainHandler.post { overlay?.aimbotActive = false; overlay?.debugBars = emptyList() }
            }
            return
        }

        val best = targets.first()

        // Scale detected head coords back to full screen pixels
        val headX = best.headX * scale
        val headY = best.headY * scale
        val screenCenter = PointF(screenW / 2f, screenH / 2f)

        // Verify target is inside FOV circle
        val dx = headX - screenCenter.x; val dy = headY - screenCenter.y
        if (dx * dx + dy * dy > fovRadiusPx * fovRadiusPx) return

        // Fire gesture on main thread (dispatchGestureAsync is thread-safe but
        // updating the overlay view requires the main thread)
        aimEngine?.aimAt(PointF(headX, headY), screenCenter)

        val scaledBars = targets.map { t ->
            RectF(t.barRect.left * scale, t.barRect.top * scale,
                  t.barRect.right * scale, t.barRect.bottom * scale)
        }

        mainHandler.post {
            overlay?.aimbotActive = true
            overlay?.debugBars = if (overlay?.showDebug == true) scaledBars else emptyList()
            overlay?.invalidate()
        }
    }

    // ── Overlay ──────────────────────────────────────────────────────────────
    private fun attachOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW not granted — overlay skipped")
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = OverlayView.attach(this, wm).also { v ->
            v.circleRadiusDp = 130f
            v.showDebug = false   // set true to see yellow health-bar outlines
        }
    }

    private fun detachOverlay() {
        overlay?.let {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            OverlayView.detach(it, wm)
        }
        overlay = null
    }

    // ── Utilities ────────────────────────────────────────────────────────────
    @Suppress("DEPRECATION")
    private fun measureScreen() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            screenW = bounds.width(); screenH = bounds.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
        fovRadiusPx = screenW * 0.135f  // ~13.5% of width ≈ 130dp on 1080p
        Log.d(TAG, "screen ${screenW}x${screenH}, fov=${fovRadiusPx}px")
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                NOTIF_CHANNEL,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { setSound(null, null) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()
}
