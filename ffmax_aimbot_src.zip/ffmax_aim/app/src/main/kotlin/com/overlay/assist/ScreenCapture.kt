// language: Kotlin, file: ScreenCapture.kt, target: Android API 26+
// Wraps MediaProjection → VirtualDisplay → ImageReader pipeline.
// Delivers ARGB_8888 Bitmap frames to a callback on a background HandlerThread.
//
// Anti-detection note:
//   libGGP.so and libanogs.so (Garena's ring-3 anti-cheat) scan:
//     • /proc/<pid>/maps for injected libs   → N/A (we're a separate process)
//     • Active MediaProjection sessions via ActivityManager
//     • Surface/SurfaceView overlay presence
//   No reliable bypass at user-space level. The VirtualDisplay flag
//   VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR is avoided; we use a private surface
//   with VIRTUAL_DISPLAY_FLAG_SECURE cleared to minimize the detection surface.
//   GGP may still flag screen capture → use alongside a dummy "screenshot helper"
//   description in the accessibility service description.

package com.overlay.assist

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log

typealias FrameCallback = (Bitmap) -> Unit

class ScreenCapture(
    private val projection: MediaProjection,
    private val screenW: Int,
    private val screenH: Int,
    private val densityDpi: Int,
    private val onFrame: FrameCallback
) {
    private val TAG = "ScreenCapture"

    // Process at half resolution for speed (still 540×1200 at 1080p device)
    private val captureW = screenW / 2
    private val captureH = screenH / 2
    val scaleX get() = screenW.toFloat() / captureW
    val scaleY get() = screenH.toFloat() / captureH

    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val thread = HandlerThread("ScreenCapture-BG").also { it.start() }
    private val handler = Handler(thread.looper)

    // Reusable Bitmap to avoid GC pressure
    private var reuseBmp: Bitmap? = null

    fun start() {
        imageReader = ImageReader.newInstance(
            captureW, captureH,
            PixelFormat.RGBA_8888,  // ImageReader doesn't support ARGB_8888 directly
            2                        // maxImages in flight
        )

        imageReader!!.setOnImageAvailableListener({ reader ->
            val image: Image? = try { reader.acquireLatestImage() } catch (e: Exception) { null }
            image ?: return@setOnImageAvailableListener
            try {
                processImage(image)
            } finally {
                image.close()
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "assist_capture",
            captureW, captureH, densityDpi,
            // No VIRTUAL_DISPLAY_FLAG_SECURE and no AUTO_MIRROR — private surface only
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY,
            imageReader!!.surface, null, null
        )

        Log.d(TAG, "capture started ${captureW}x${captureH}")
    }

    fun stop() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        thread.quitSafely()
        projection.stop()
        reuseBmp?.recycle()
        reuseBmp = null
        Log.d(TAG, "capture stopped")
    }

    // ── Frame processing ─────────────────────────────────────────────────────
    private fun processImage(image: Image) {
        val planes = image.planes
        if (planes.isEmpty()) return

        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * captureW

        // Allocate / reuse Bitmap
        val bmpW = captureW + rowPadding / pixelStride
        val bmp = reuseBmp?.takeIf { it.width == bmpW && it.height == captureH }
            ?: Bitmap.createBitmap(bmpW, captureH, Bitmap.Config.ARGB_8888).also { reuseBmp = it }

        bmp.copyPixelsFromBuffer(plane.buffer)

        // Crop to exact capture size if bmpW > captureW
        val out = if (bmpW > captureW)
            Bitmap.createBitmap(bmp, 0, 0, captureW, captureH)
        else bmp

        onFrame(out)
    }
}
