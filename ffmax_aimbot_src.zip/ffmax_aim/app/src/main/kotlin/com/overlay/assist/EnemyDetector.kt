// language: Kotlin, file: EnemyDetector.kt, target: Android API 26+
// Pixel-based enemy health bar detection for Free Fire MAX (com.dts.freefiremax)
// Works on ARGB_8888 Bitmap frames from ImageReader (MediaProjection pipeline).
//
// Strategy: scan for red pixel clusters matching FF enemy health bar signature.
// FF health bars: solid red strip ~6-14px tall, ~40-140px wide, floating above enemy head.
// Color signature: R ∈ [195,255], G ∈ [0,65], B ∈ [0,65].
// Head position = cluster center_x, cluster top_y − headOffset.

package com.overlay.assist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF

data class EnemyTarget(
    val headX: Float,   // pixel coord on screen
    val headY: Float,
    val barRect: RectF  // bounding box of detected health bar (debug)
)

object EnemyDetector {

    // ── Tunable constants ────────────────────────────────────────────────────
    private const val R_MIN = 195; private const val R_MAX = 255
    private const val G_MAX = 65;  private const val B_MAX = 65

    // Health bar size constraints (pixels at 1080p; scale if needed)
    private const val BAR_W_MIN = 28
    private const val BAR_W_MAX = 160
    private const val BAR_H_MIN = 3
    private const val BAR_H_MAX = 18

    // How far above the health bar center the head is (empirical for FF MAX)
    private const val HEAD_Y_OFFSET = 48f

    // Sub-sample stride: check every N pixels for speed (2 = half res scan)
    private const val STRIDE = 2

    // ── Main entry ───────────────────────────────────────────────────────────
    /**
     * Scan [bmp] within [fovRect] for enemy health bars.
     * Returns all detected targets, closest-to-FOV-center first.
     */
    fun detect(bmp: Bitmap, fovRect: RectF): List<EnemyTarget> {
        val w = bmp.width; val h = bmp.height
        val x0 = fovRect.left.toInt().coerceAtLeast(0)
        val y0 = fovRect.top.toInt().coerceAtLeast(0)
        val x1 = fovRect.right.toInt().coerceAtMost(w - 1)
        val y1 = fovRect.bottom.toInt().coerceAtMost(h - 1)

        // Pixel array extraction (faster than per-pixel getPixel)
        val scanW = x1 - x0
        val scanH = y1 - y0
        if (scanW <= 0 || scanH <= 0) return emptyList()

        val pixels = IntArray(scanW * scanH)
        bmp.getPixels(pixels, 0, scanW, x0, y0, scanW, scanH)

        // Collect candidate red pixels into a visited grid
        val redMap = Array(scanH) { BooleanArray(scanW) }
        for (py in 0 until scanH step STRIDE) {
            for (px in 0 until scanW step STRIDE) {
                val c = pixels[py * scanW + px]
                if (isEnemyRed(c)) redMap[py][px] = true
            }
        }

        // Horizontal run-length clustering: find red horizontal spans
        val spans = mutableListOf<IntArray>() // [xStart, xEnd, y]
        for (py in 0 until scanH step STRIDE) {
            var runStart = -1
            for (px in 0 until scanW step STRIDE) {
                val red = redMap[py][px]
                if (red && runStart < 0) { runStart = px }
                if (!red && runStart >= 0) {
                    spans += intArrayOf(runStart, px - STRIDE, py)
                    runStart = -1
                }
            }
            if (runStart >= 0) spans += intArrayOf(runStart, scanW - 1, py)
        }

        // Merge nearby spans into bar candidates
        val bars = mergeSpansToBars(spans, scanW)

        // Filter by geometry, map to screen coords, compute head positions
        val fovCx = fovRect.centerX(); val fovCy = fovRect.centerY()
        val targets = bars.mapNotNull { bar ->
            val bw = bar.right - bar.left
            val bh = bar.bottom - bar.top
            if (bw < BAR_W_MIN || bw > BAR_W_MAX || bh < BAR_H_MIN || bh > BAR_H_MAX) return@mapNotNull null
            // Map back to screen coordinates
            val sx = (bar.left + x0).toFloat()
            val sy = (bar.top  + y0).toFloat()
            val sw = bw.toFloat(); val sh = bh.toFloat()
            val screenRect = RectF(sx, sy, sx + sw, sy + sh)
            val headX = screenRect.centerX()
            val headY = screenRect.top - HEAD_Y_OFFSET
            EnemyTarget(headX, headY, screenRect)
        }

        // Sort by proximity to FOV center (nearest first = priority target)
        return targets.sortedBy { t ->
            val dx = t.headX - fovCx; val dy = t.headY - fovCy
            dx * dx + dy * dy
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun isEnemyRed(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return r in R_MIN..R_MAX && g <= G_MAX && b <= B_MAX
    }

    /**
     * Group horizontal spans that overlap vertically within [vGap] rows
     * into bounding rectangles.
     */
    private fun mergeSpansToBars(
        spans: List<IntArray>,
        vGap: Int = 6
    ): List<android.graphics.Rect> {
        if (spans.isEmpty()) return emptyList()
        data class Bar(var x0: Int, var x1: Int, var y0: Int, var y1: Int)

        val open = mutableListOf<Bar>()
        val closed = mutableListOf<Bar>()

        for ((sx, ex, py) in spans.map { Triple(it[0], it[1], it[2]) }) {
            // Find an open bar that overlaps horizontally and is close vertically
            val match = open.firstOrNull { b ->
                py - b.y1 <= vGap && sx <= b.x1 + 10 && ex >= b.x0 - 10
            }
            if (match != null) {
                match.x0 = minOf(match.x0, sx)
                match.x1 = maxOf(match.x1, ex)
                match.y1 = py
            } else {
                open += Bar(sx, ex, py, py)
            }
        }
        // Close bars where last row was too far back
        val all = open + closed
        return all.map { android.graphics.Rect(it.x0, it.y0, it.x1, it.y1) }
    }
}
