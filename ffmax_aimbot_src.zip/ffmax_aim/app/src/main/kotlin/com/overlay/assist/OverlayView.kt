// language: Kotlin, file: OverlayView.kt, target: Android API 26+
// Transparent overlay displaying the green FOV circle.
// Drawn via WindowManager TYPE_APPLICATION_OVERLAY (no root, user grants SYSTEM_ALERT_WINDOW).
// The circle:
//   - Center = screen center (= crosshair position in FF)
//   - Radius = adjustable, default 130dp
//   - Stroke only (transparent interior so game is visible)
//   - Color: semi-transparent green (#8000FF00) when idle, solid when aimbot fires
// Also renders small red rectangles for each detected enemy bar (debug toggle).

package com.overlay.assist

import android.content.Context
import android.graphics.*
import android.view.View
import android.view.WindowManager
import kotlin.math.roundToInt

class OverlayView(context: Context) : View(context) {

    // ── State ────────────────────────────────────────────────────────────────
    var circleRadiusDp: Float = 130f
        set(v) { field = v; invalidate() }

    var aimbotActive = false   // true = solid bright green; false = dim ring
        set(v) { field = v; invalidate() }

    // List of detected health bar rects (in screen pixels) for debug overlay
    var debugBars: List<RectF> = emptyList()
        set(v) { field = v; invalidate() }

    var showDebug = false

    // ── Paint ────────────────────────────────────────────────────────────────
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(180, 0, 255, 0)
    }
    private val debugBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Color.YELLOW
    }
    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(200, 0, 255, 120)
    }

    // ── Draw ─────────────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val density = resources.displayMetrics.density
        val radiusPx = circleRadiusDp * density

        // Ring color: dim when idle, bright when locking
        ringPaint.color = if (aimbotActive)
            Color.argb(230, 0, 255, 60)
        else
            Color.argb(120, 0, 200, 60)
        ringPaint.strokeWidth = if (aimbotActive) 4f else 2.5f

        canvas.drawCircle(cx, cy, radiusPx, ringPaint)

        // Center dot
        canvas.drawCircle(cx, cy, 3f, dotPaint)

        // Mini crosshair lines
        val cLen = 12f
        canvas.drawLine(cx - cLen, cy, cx + cLen, cy, crosshairPaint)
        canvas.drawLine(cx, cy - cLen, cx, cy + cLen, crosshairPaint)

        // Debug: draw detected health bar outlines
        if (showDebug && debugBars.isNotEmpty()) {
            for (bar in debugBars) canvas.drawRect(bar, debugBarPaint)
        }
    }

    // ── Factory / attach / detach ─────────────────────────────────────────
    companion object {
        fun attach(ctx: Context, wm: WindowManager): OverlayView {
            val view = OverlayView(ctx)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(view, params)
            return view
        }

        fun detach(view: OverlayView, wm: WindowManager) {
            try { wm.removeView(view) } catch (_: Exception) {}
        }
    }
}
