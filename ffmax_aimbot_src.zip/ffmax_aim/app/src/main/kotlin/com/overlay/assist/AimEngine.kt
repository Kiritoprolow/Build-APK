// language: Kotlin, file: AimEngine.kt, target: Android API 26+
// Translates pixel-delta (screen center → enemy head) into right-joystick
// swipe gestures dispatched through AccessibilityService.dispatchGestureAsync().
//
// Free Fire camera control: right-side drag zone (~55%-100% of screen width).
// Swiping RIGHT on the drag zone rotates view LEFT (standard inverted axis).
// Pixel → camera angle mapping is not 1:1; sensitivityX/Y must be calibrated
// per DPI / in-game sensitivity setting (defaults tuned for 1080p, sens=100).

package com.overlay.assist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock

class AimEngine(private val service: AccessibilityService) {

    // ── Config ───────────────────────────────────────────────────────────────
    // Right-side joystick anchor (fraction of screen w/h)
    var joystickCenterXFrac = 0.765f
    var joystickCenterYFrac = 0.640f

    // Pixel → touch-swipe scale: larger = bigger swipe per pixel of delta
    // Empirical for FF MAX at 1080×2400, in-game look sensitivity 100
    var sensitivityX = 0.072f
    var sensitivityY = 0.068f

    // Swipe gesture duration in ms. Lower = faster snap; too low causes misfire
    var aimDurationMs = 85L

    // Minimum pixel delta to bother firing (dead-zone)
    var minDelta = 6f

    // Anti-spam: minimum ms between consecutive gestures
    var cooldownMs = 110L

    private var lastGestureAt = 0L
    private var screenW = 1080f
    private var screenH = 2400f

    fun setScreenSize(w: Int, h: Int) { screenW = w.toFloat(); screenH = h.toFloat() }

    // ── Public API ───────────────────────────────────────────────────────────
    /**
     * Dispatch a swipe gesture that moves the camera so the crosshair lands
     * on [targetHead]. Fires only when delta > [minDelta] and cooldown has elapsed.
     *
     * @param targetHead  screen-pixel position of enemy head
     * @param screenCenter  center of screen (FOV circle center, = crosshair position)
     */
    fun aimAt(targetHead: PointF, screenCenter: PointF) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastGestureAt < cooldownMs) return

        val dx = targetHead.x - screenCenter.x
        val dy = targetHead.y - screenCenter.y

        if (dx * dx + dy * dy < minDelta * minDelta) return  // already on target

        // Joystick anchor point (absolute pixels)
        val jx = joystickCenterXFrac * screenW
        val jy = joystickCenterYFrac * screenH

        // Swipe delta: pixel offset translates to camera rotation
        // FF camera: drag RIGHT → look LEFT, drag DOWN → look UP
        // So to aim AT (dx, dy) from center: swipe in same direction as delta
        val swipeDx = dx * sensitivityX
        val swipeDy = dy * sensitivityY

        val endX = (jx + swipeDx).coerceIn(jx - 200f, jx + 200f)
        val endY = (jy + swipeDy).coerceIn(jy - 300f, jy + 300f)

        val path = Path().apply {
            moveTo(jx, jy)
            lineTo(endX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0L, aimDurationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGestureAsync(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                lastGestureAt = SystemClock.elapsedRealtime()
            }
            override fun onCancelled(gestureDescription: GestureDescription) { /* retry next frame */ }
        }, null)

        lastGestureAt = now  // optimistic update prevents burst
    }
}
